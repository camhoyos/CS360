package com.zybooks.templateproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    private EditText mNameEditText;
    private TextView mTextGreeting;
    private Button mbuttonSayHello;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mNameEditText = findViewById(R.id.nameText);
        mTextGreeting = findViewById(R.id.textGreeting);
        mbuttonSayHello = findViewById(R.id.buttonSayHello);

        mNameEditText.addTextChangedListener(nameTextWatcher);
    }

    private TextWatcher nameTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }
        //Button enable validation based on text change
        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            String nameInput = mNameEditText.getText().toString().trim();
            mbuttonSayHello.setEnabled(!nameInput.isEmpty());
        }

        @Override
        public void afterTextChanged(Editable editable) {

        }
    };
    
    public void SayHello(View view){
        // Get name to concatenate
        String name = null;
        try{
            name = mNameEditText.getText().toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        /*Due to button validation, this if statement appears to be dead code
        Leaving in source as provided as a requirement*/
        if (mNameEditText.getText().length() == 0){
            String fullText = "You must enter a name";
            mTextGreeting.setText(fullText);
        } else {
            String fullText = "Hello " + name;
            mTextGreeting.setText(fullText);
        }
    }
}