package com.cs360class.weighttrackingapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class LoginDatabase extends SQLiteOpenHelper {

    private static final int version = 1;
    private static final String databaseName = "login.db";
    SQLiteDatabase db;

    private static final String databasePath = "/";

    public LoginDatabase(Context context) {
        super(context, databaseName, null, version);
    }

    private static final class loginTable {
        private static final String table = "users";
        private static final String colUsers = "emailAddress";
        private static final String colPass = "password";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        //Create user database
        db.execSQL("create table " + loginTable.table + " (" +
                loginTable.colUsers + " primary key, " +
                loginTable.colPass + " )");

        //Add test user
        ContentValues values = new ContentValues();
        values.put(loginTable.colUsers, "testemail@gmail.com");
        values.put(loginTable.colPass, "password123");
        db.insert(loginTable.table, null, values);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + loginTable.table);
        onCreate(db);
    }

    public boolean checkUserLogin(String emailAddress, String password){
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select * from " + loginTable.table +
                " where " + loginTable.colUsers + " = ?" +
                " and " +loginTable.colPass + " = ?";

        Cursor cursor = db.rawQuery(sql, new String[] { emailAddress, password });

        if(cursor.getCount()==0) {
            return false;
        } else {
            return true;
        }
    }

    public boolean addUser(String emailAddress, String password){
        //Check to make sure user does not exist
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select * from " + loginTable.table +
                " where " + loginTable.colUsers + " = ?";

        Cursor cursor = db.rawQuery(sql, new String[] { emailAddress });

        if(cursor.getCount()==0) {
            ContentValues values = new ContentValues();
            values.put(loginTable.colUsers, emailAddress);
            values.put(loginTable.colPass, password);
            db.insert(loginTable.table, null, values);
            return false;
        } else {
            return true;
        }
    }
}
