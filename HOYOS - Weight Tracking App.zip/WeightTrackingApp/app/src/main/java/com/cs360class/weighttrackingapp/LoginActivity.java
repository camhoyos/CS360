package com.cs360class.weighttrackingapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    Button btnLogin;
    Button btnRegister;
    EditText editUser;
    EditText editPassw;
    LoginDatabase loginDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_layout);

        btnLogin = findViewById(R.id.loginButton);
        btnRegister = findViewById(R.id.registerButton);
        editUser = findViewById(R.id.editLoginEmailAddress);
        editPassw = findViewById(R.id.editLoginPassword);

        loginDatabase = new LoginDatabase(LoginActivity.this);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean userExists = loginDatabase.checkUserLogin(editUser.getText().toString(), editPassw.getText().toString());

                if(userExists){
                    Intent intent = new Intent(LoginActivity.this, WeightTrackingActivity.class);
                    intent.putExtra("emailAddress", editUser.getText().toString());
                    startActivity(intent);
                } else {
                    editPassw.setText(null);
                    Toast.makeText(LoginActivity.this, "Login failed. Invalid username or password.", Toast.LENGTH_SHORT).show();
                }

            }
        });

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean userExists = loginDatabase.addUser(editUser.getText().toString(), editPassw.getText().toString());

                if(userExists){
                    Toast.makeText(LoginActivity.this, "User already exists, please attempt to login!", Toast.LENGTH_SHORT).show();
                } else {
                    Intent intent = new Intent(LoginActivity.this, WeightTrackingActivity.class);
                    intent.putExtra("emailAddress", editUser.getText().toString());
                    startActivity(intent);
                }

            }
        });

    }
}