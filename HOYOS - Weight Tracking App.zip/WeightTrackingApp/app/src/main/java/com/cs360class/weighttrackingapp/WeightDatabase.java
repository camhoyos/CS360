package com.cs360class.weighttrackingapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class WeightDatabase extends SQLiteOpenHelper {

    private static final int VERSION = 1;
    private static final String DATABASE_NAME = "weight.db";

    private static WeightDatabase mWeightdb;

    public static WeightDatabase getInstance(Context context) {
        if (mWeightdb == null) {
            mWeightdb = new WeightDatabase(context);
        }
        return mWeightdb;
    }

    private WeightDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class WeightTable {
        private static final String TABLE = "weights";
        private static final String COL_DATE = "date";
        private static final String COL_WEIGHT = "weight";
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create weights table
        db.execSQL("create table " + WeightTable.TABLE + " (" +
                WeightTable.COL_DATE + " primary key, " +
                WeightTable.COL_WEIGHT + " int)");

        //Add test entries
        ContentValues values = new ContentValues();
        values.put(WeightTable.COL_DATE, "08/09/2020");
        values.put(WeightTable.COL_WEIGHT, 190);
        Log.println(Log.INFO, "INSERT", db.insert(WeightTable.TABLE, null, values) +" ID" );

        values.put(WeightTable.COL_DATE, "08/10/2020");
        values.put(WeightTable.COL_WEIGHT, 189);
        Log.println(Log.INFO, "INSERT", db.insert(WeightTable.TABLE, null, values) +" ID" );

        values.put(WeightTable.COL_DATE, "08/11/2020");
        values.put(WeightTable.COL_WEIGHT, 188);
        Log.println(Log.INFO, "INSERT", db.insert(WeightTable.TABLE, null, values) +" ID" );

        values.put(WeightTable.COL_DATE, "08/12/2020");
        values.put(WeightTable.COL_WEIGHT, 187);
        Log.println(Log.INFO, "INSERT", db.insert(WeightTable.TABLE, null, values) +" ID" );

        values.put(WeightTable.COL_DATE, "08/13/2020");
        values.put(WeightTable.COL_WEIGHT, 186);
        Log.println(Log.INFO, "INSERT", db.insert(WeightTable.TABLE, null, values) +" ID" );

        values.put(WeightTable.COL_DATE, "08/14/2020");
        values.put(WeightTable.COL_WEIGHT, 185);
        Log.println(Log.INFO, "INSERT", db.insert(WeightTable.TABLE, null, values) +" ID" );

        values.put(WeightTable.COL_DATE, "08/15/2020");
        values.put(WeightTable.COL_WEIGHT, 184);
        Log.println(Log.INFO, "INSERT", db.insert(WeightTable.TABLE, null, values) +" ID" );

        values.put(WeightTable.COL_DATE, "08/16/2020");
        values.put(WeightTable.COL_WEIGHT, 183);
        Log.println(Log.INFO, "INSERT", db.insert(WeightTable.TABLE, null, values) +" ID" );

        values.put(WeightTable.COL_DATE, "08/17/2020");
        values.put(WeightTable.COL_WEIGHT, 182);
        Log.println(Log.INFO, "INSERT", db.insert(WeightTable.TABLE, null, values) +" ID" );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + WeightTable.TABLE);
        onCreate(db);
    }

    public List<Weight> getWeights() {
        List<Weight> weights = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();

        String sql = "select * from " + WeightTable.TABLE +
                " where " + WeightTable.COL_DATE + " != ?";

        Cursor cursor = db.rawQuery(sql, new String[] { "TARGET" });
        if (cursor.moveToFirst()) {
            do {
                Weight weight = new Weight("", 0);
                weight.setDate(cursor.getString(0));
                weight.setWeight(cursor.getInt(1));
                weights.add(weight);
            } while (cursor.moveToNext());
        }
        cursor.close();

        return weights;
    }

    public int getWeight(String date) {
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select * from " + WeightTable.TABLE +
                " where " + WeightTable.COL_DATE + " = ?";

        Cursor cursor = db.rawQuery(sql, new String[] { date });

        if(cursor.moveToFirst()) {
            return cursor.getInt(1);
        } else {
            return 0;
        }
    }

    public boolean addWeight(Weight weight) {
        //Check to make sure date does not exist
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select * from " + WeightTable.TABLE +
                " where " + WeightTable.COL_DATE + " = ?";

        Cursor cursor = db.rawQuery(sql, new String[] { weight.getDate() });

        if(cursor.getCount()==0) {
            ContentValues values = new ContentValues();
            values.put(WeightTable.COL_DATE, weight.getDate());
            values.put(WeightTable.COL_WEIGHT, weight.getWeight());
            db.insert(WeightTable.TABLE, null, values);
            return true;
        } else {
            return false;
        }
    }

    public boolean updateWeight(Weight weight, String oldDate) {
        //Check to make sure date does exist
        SQLiteDatabase db = this.getReadableDatabase();
        String sqlOld = "select * from " + WeightTable.TABLE +
                " where " + WeightTable.COL_DATE + " = ?";

        Cursor cursor = db.rawQuery(sqlOld, new String[] { oldDate });

        //Check to prevent key collision
        String sqlNew = "select * from " + WeightTable.TABLE +
                " where " + WeightTable.COL_DATE + " = ?";

        Cursor cursorCheck = db.rawQuery(sqlNew, new String[] { weight.getDate() });

        if(cursor.getCount()==1 && cursorCheck.getCount()==0) {
            ContentValues values = new ContentValues();
            values.put(WeightTable.COL_DATE, weight.getDate());
            values.put(WeightTable.COL_WEIGHT, weight.getWeight());
            db.update(WeightTable.TABLE, values,
                    WeightTable.COL_DATE + " = ?", new String[] { oldDate });
            return true;
        } else if(cursor.getCount()==1 && oldDate.compareTo(weight.getDate())==0) {
            ContentValues values = new ContentValues();
            values.put(WeightTable.COL_DATE, weight.getDate());
            values.put(WeightTable.COL_WEIGHT, weight.getWeight());
            db.update(WeightTable.TABLE, values,
                    WeightTable.COL_DATE + " = ?", new String[] { oldDate });
            return true;
        } else {
            return false;
        }
    }

    public void deleteWeight(Weight weight) {
        SQLiteDatabase db = this.getReadableDatabase();
        db.delete(WeightTable.TABLE,
                WeightTable.COL_DATE + " = ?", new String[] { weight.getDate() });
    }
}
