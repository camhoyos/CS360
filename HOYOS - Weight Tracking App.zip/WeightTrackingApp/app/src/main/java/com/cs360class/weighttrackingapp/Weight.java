package com.cs360class.weighttrackingapp;

public class Weight {

    private String mDate;
    private int mWeight;

    public Weight(String date, int weight){
        mDate = date;
        mWeight = weight;
    }

    public String getDate() {
        return mDate;
    }

    public void setDate(String date){
        mDate = date;
    }

    public int getWeight() {
        return mWeight;
    }

    public void setWeight(int weight){
        mWeight = weight;
    }

}
